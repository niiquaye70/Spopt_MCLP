#importing necessary packages
import geopandas as gpd
import folium
import pandas as pd
from shapely.geometry import Point
from spopt.locate import simulated_geo_points
import pulp
import routingpy
from routingpy import OSRM
import shapely
from shapely.geometry import shape, Point
import spopt
import numpy as np
import matplotlib.pyplot as plt
from spopt.locate import MCLP
import os
workspace = os.getcwd()

# Load areas of interest (shapefile)
pf_region = "pf_region.shp"
gdf = gpd.read_file(pf_region)


# Visualize the low-income region
gdf.plot()
plt.show()

print(gdf.crs)


NUM_HOUSEHOLDS = 200

# Generate the households as random points within the region
households = simulated_geo_points(gdf, needed=NUM_HOUSEHOLDS, seed=0)
print(households)
# Convert households to a list of coordinates
households_coords = households.geometry.map(lambda pt: [pt.x, pt.y]).to_list()

# Check the first few coordinates
print(households_coords[:5])


# Create a base map centered on the geometry
region_center = [gdf.geometry.centroid.y.mean(), gdf.geometry.centroid.x.mean()]
m = folium.Map(location=region_center, zoom_start=14, tiles="cartodbpositron")

# Add GeoJSON boundary of the region
folium.GeoJson(
    data=gdf.geometry.to_json(),
    name="Region Boundary",
    style_function=lambda x: {"color": "blue", "fillColor": "lightblue"}
).add_to(m)

m.save("Base Map.html")
m

# Add households as blue points
for coord in households_coords:
    folium.CircleMarker(
        location=[coord[1], coord[0]],
        radius=3,
        fill=True,
        fill_opacity=1,
        color="cornflowerblue",
        popup="Household"
    ).add_to(m)

# Save and display the map
m.save("households_map.html")


# Load the CSV file
grocery_df = pd.read_csv("grocery_store.csv")

# Ensure the latitude and longitude columns are present
print(grocery_df.head())

# Create a GeoDataFrame with the projected CRS (e.g., EPSG:2272)
groceries_gdf = gpd.GeoDataFrame(
    grocery_df,
    geometry=gpd.points_from_xy(grocery_df['POINT_X'], grocery_df['POINT_Y']),
    crs="EPSG:2272"  # Projected CRS (update if necessary)
)

# Check the CRS
print("Original CRS:", groceries_gdf.crs)

# Re-project to geographic CRS (EPSG:4326)
groceries_gdf = groceries_gdf.to_crs("EPSG:4326")
print("Re-projected CRS:", groceries_gdf.crs)
print(groceries_gdf.head())

# Extract grocery coordinates as latitude and longitude
grocery_coords = groceries_gdf.geometry.map(lambda pt: [pt.x, pt.y]).to_list()
print("First few grocery coordinates:", grocery_coords[:5])

# Add grocery stores to the map as green points
# Add grocery stores to the map with shopping cart icons
for i, coord in enumerate(grocery_coords):
    folium.Marker(
        location=[coord[1], coord[0]],  # Latitude, longitude
        icon=folium.Icon(icon="shopping-cart", prefix="fa", color="green"),
        popup=f"Grocery Store {i}"
    ).add_to(m)

# Save and display the map
m.save("households_and_groceries_map_with_icons.html")
m

# Combine all locations (households + grocery stores)
all_locations = households_coords + grocery_coords

# Define indices for sources (households) and destinations (grocery stores)
source_indices = list(range(len(households_coords)))  # Indices of households
target_indices = list(range(len(households_coords), len(all_locations)))  # Indices of grocery stores

# Initialize the OSRM client
client = OSRM(base_url="https://router.project-osrm.org")

# Compute the distance matrix (travel times in seconds)
osrm_routing_matrix = client.matrix(
    locations=all_locations,
    sources=source_indices,
    destinations=target_indices,
    profile="pedestrian"  # Use pedestrian mode for walking distances
)

# Extract durations and convert to a NumPy array
cost_matrix = np.array(osrm_routing_matrix.durations)
print(cost_matrix)
# Check the dimensions of the matrix
# (Number of households, Number of grocery stores)
print("Cost matrix shape:", cost_matrix.shape)  


# Set MCLP parameters
SERVICE_RADIUS = 300  # Maximum acceptable service time (e.g., 5 minutes in seconds)
P_FACILITIES = 3      # Number of grocery stores to site
wght = np.ones((1, len(households_coords)), dtype=int)  # Equal weights for households

# Initialize and solve the MCLP
solver = pulp.COIN_CMD(path= "C:/cbc/bin/cbc.exe",msg=False)
mclp = MCLP.from_cost_matrix(cost_matrix, wght , SERVICE_RADIUS, p_facilities=P_FACILITIES)
mclp = mclp.solve(solver)

# Print results
obj_val = int(mclp.problem.objective.value())
obj_perc = mclp.perc_cov

#Evaluated the results 
print(
    f"Of the {len(households_coords)} households, {obj_val} have access to at least 1 "
    f"grocery store within a {SERVICE_RADIUS // 60}-minute walk. This is {obj_perc:} coverage."
)


# Create feature groups for sited grocery stores and allocated households
sited_groceries_fg = folium.FeatureGroup("Sited Grocery Stores").add_to(m)
allocated_households_fg = folium.FeatureGroup("Allocated Households").add_to(m)

# Use distinct colors for visualization
colors = ["darkcyan", "saddlebrown", "coral", "gold", "purple", "blue", "lime", "orange", "pink"]

for i in range(len(grocery_coords)):
    if mclp.fac2cli[i]:  # Check if the grocery was selected
        folium.Marker(
            location=[grocery_coords[i][1], grocery_coords[i][0]],
            icon=folium.Icon(
                icon="shopping-cart",
                prefix="fa",
                color="red"
            ),
            popup=f"Sited Grocery {i}"
        ).add_to(sited_groceries_fg)

        for j in mclp.fac2cli[i]:  # Allocated households
            folium.CircleMarker(
                location=[households_coords[j][1], households_coords[j][0]],
                radius=10,
                fill=True,
                color=colors[i % len(colors)]
            ).add_to(allocated_households_fg)

# Add a layer control and save the map
folium.LayerControl().add_to(m)
m.save("final_solution_map.html")
m



