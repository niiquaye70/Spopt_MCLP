# Importing necessary packages
import geopandas as gpd
import folium
import pandas as pd
import pulp
import routingpy
from routingpy import OSRM
import spopt
import numpy as np
import matplotlib.pyplot as plt
from spopt.locate import MCLP

# Step 1: Load the region of interest (shapefile)
region_shapefile = "path_to_your_region_shapefile.shp"  # <-- Replace with your file path
gdf = gpd.read_file(region_shapefile)

# Visualize the region
gdf.plot()
plt.show()

print(gdf.crs)  # Check CRS of the shapefile

# Step 2: Load demand points (parks or recreation areas shapefile)
demand_shapefile = "path_to_your_demand_shapefile.shp"  # <-- Replace with your file path
demand_gdf = 


# Extract coordinates of demand points
demand_coords = demand_gdf.geometry.map(lambda pt: [pt.x, pt.y]).to_list()
print("First few demand coordinates:", demand_coords[:5])

# Step 3: Load facility locations (e.g., bus shelters shapefile)
facility_shapefile = "path_to_your_facility_shapefile.shp"  # <-- Replace with your file path
facility_gdf = 

# Re-project facility points to geographic CRS if needed
facility_gdf = facility_gdf.to_crs("EPSG:4326")  # Ensure CRS is geographic
print("Facility CRS:", facility_gdf.crs)

# Extract coordinates of facility points
facility_coords = facility_gdf.geometry.map(lambda pt: [pt.x, pt.y]).to_list()
print("First few facility coordinates:", facility_coords[:4])

# Step 4: Create a base map
region_center = [gdf.geometry.centroid.y.mean(), gdf.geometry.centroid.x.mean()]
m = folium.Map(location=region_center, zoom_start=12, tiles="cartodbpositron")

# Add region boundary to the map
folium.GeoJson(
    data=gdf.geometry.to_json(),
    name="Region Boundary",
    style_function=lambda x: {"color": "blue", "fillColor": "lightblue"}
).add_to(m)

m.save("regioncenter.html")

# Add demand points to the map
for coord in demand_coords:
    folium.CircleMarker(
        location=[coord[1], coord[0]],  # Latitude, longitude
        radius=3,
        fill=True,
        fill_opacity=1,
        color="yellow",
        popup="Demand Point"
    ).add_to(m)

# Add facility points to the map
for i, coord in enumerate(facility_coords):
    folium.Marker(
        location=[coord[1], coord[0]],  # Latitude, longitude
        icon=folium.Icon(icon="home", prefix="fa", color="red"),
        popup=f"Facility {i}"
    ).add_to(m)

m.save("base_map_with_demand_and_facilities.html")

# Step 5: Combine locations and compute distance matrix
all_locations = 
source_indices = list(range(len(demand_coords)))  # Demand points as sources
target_indices = list(range(len(demand_coords), len(all_locations)))  # Facility points as destinations

# Initialize OSRM client and calculate drive time matrix
client = OSRM(base_url="https://router.project-osrm.org")
osrm_routing_matrix = client.matrix(
    locations=all_locations,
    sources=source_indices,
    destinations=target_indices,
    profile=""  
)

# Convert durations to NumPy array
cost_matrix = np.array(osrm_routing_matrix.durations)
print("Cost Matrix Shape:", cost_matrix.shape)

# Step 6: Solve the MCLP
SERVICE_RADIUS =   
P_FACILITIES =   
wght = np.ones((1, len(demand_coords)), dtype=int)  

solver = pulp.COIN_CMD(path="", msg=False)  # Replace with your CBC solver path
mclp = MCLP.from_cost_matrix(cost_matrix, wght, SERVICE_RADIUS, p_facilities=P_FACILITIES)
mclp = mclp.solve(solver)

# Step 7: Evaluate and print results
obj_val = int(mclp.problem.objective.value())
obj_perc = mclp.perc_cov
print(................................................  # Put the print statement here 
      ..................................)


# Step 8: Visualize results
sited_facilities_fg = folium.FeatureGroup("Sited Facilities").add_to(m)
allocated_demand_fg = folium.FeatureGroup("Allocated Demand Points").add_to(m)

colors = [...............................]

for i in range(len(facility_coords)):
    if mclp.fac2cli[i]:  # Check if the facility was selected
        folium.Marker(
            location=[facility_coords[i][1], facility_coords[i][0]],
            icon=folium.Icon(icon="check-circle", prefix="fa", color="green"),
            popup=f"Sited Facility {i}"
        ).add_to(sited_facilities_fg)

        for j in mclp.fac2cli[i]:  # Allocated demand points
            folium.CircleMarker(
                location=[demand_coords[j][1], demand_coords[j][0]],
                radius=10,
                fill=True,
                color=colors[i % len(colors)],
                popup=f"Allocated to Facility {i}"
            ).add_to(allocated_demand_fg)

# Add layer control and save the final map
folium.LayerControl().add_to(m)
m.save("Exercise_final_solution_map.html")
